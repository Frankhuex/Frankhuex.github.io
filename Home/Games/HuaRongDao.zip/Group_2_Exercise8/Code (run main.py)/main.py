import numpy as np
import pygame
from pygame.locals import *

from State import State
from Queue import Queue
from Stack import Stack
from Solver import Solver
from Const import *

pygame.init()

# Game Setting
#######################

'''
Five variables can be modified: 
    size, board, algorithm, depth_limit_option, depth
'''

# size=(row,column)
size=(3,3)

# Generate the goal state for you to mess up:
board=State.generate_goal_board(size)

# You can write your own board if you like:
board=[[2,4,3],[8,0,5],[1,7,6]]

# Choose algorithm from algorithm_list:
# algorithm_list=["BFS","UCS","DFS","Greedy","A*"]
algorithm="Greedy"

# Choose depth limit option from depth_limit_list:
# depth_limit_list=["DLS","IDS",None]
depth_limit_option="IDS"
depth=10

#######################

# These are for reference:
'''
algorithm_table={
    "BFS":"Breadth-first search",
    "UCS":"Uniform-cost search",
    "DFS":"Depth-first search",

    "Greedy":"Greedy search",
    "A*":"A* search"
}
depth_limit_option_table={
    "DLS":"Depth-limited search",
    "IDS":"Iterative deepening search",
}
'''

# Pygame setup
screen=pygame.display.set_mode((size[1]*BLOCK_WID,size[0]*BLOCK_WID))
pygame.display.set_caption("Klotski")
clock=pygame.time.Clock()
myfont=pygame.font.Font(None,TEXT_HEIGHT)

if __name__=="__main__":
    run=[True]
    solver1=Solver(size,board)
    while run[0]:
        solver1.mess_state(screen,clock,myfont,run)
        solver1.solution_state(screen,clock,myfont,run,algorithm,depth_limit_option,depth)
    
