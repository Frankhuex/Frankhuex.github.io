BLOCK_WID=60
BLOCK_MARGIN=5
BORDER_RADIUS=3

TEXT_HEIGHT=40

FPS=120
BLUE=(10,80,255)
WHITE=(255,255,255)

BLOCK_COLOR=BLUE
LINE_COLOR=WHITE
TEXT_COLOR=WHITE

def light(color):
    r=color[0]+100 if color[0]+100<=255 else 255
    g=color[1]+100 if color[1]+100<=255 else 255
    b=color[2]+100 if color[2]+100<=255 else 255
    return (r,g,b)