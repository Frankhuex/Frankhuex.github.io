import numpy as np
import copy
class State:
    def __init__(self,size,board,g_step):
        self.size=size

        self.goal=self.get_goal_board()
        self.board=np.array(board)

        self.g_step=g_step
        self.h_step=self.get_h_step()
        self.f_step=self.get_f_step()

        self.route=[]

    # goal board generation for the object
    def get_goal_board(self):
        return State.generate_goal_board(self.size)

    # goal board generation for the class
    def generate_goal_board(size):
        board=np.array([[0]*size[1] for i in range(size[0])])
        for i in range(size[0]):
            for j in range(size[1]):
                board[i][j]=size[1]*i+j+1
        board[size[0]-1][size[1]-1]=0
        return board

    # update h function
    def get_h_step(self):
        h_step=0
        for i in range(self.size[0]):
            for j in range(self.size[1]):
                value=self.board[i][j]
                if value!=0:
                    i_goal,j_goal=divmod(value-1,self.size[1])
                    h_step+=abs(i-i_goal)+abs(j-j_goal)
                else:
                    i0,j0=self.find0()
                    h_step+=abs(i-i0)+abs(j-j0)
        self.h_step=h_step
        return h_step
    
    # update h and f function
    def get_f_step(self):
        f_step=self.g_step+self.get_h_step()
        self.f_step=f_step
        return f_step

    # find the position of 0, the blank block
    def find0(self):
        for i in range(self.size[0]):
            for j in range(self.size[1]):
                if self.board[i][j]==0:
                    return i,j

    # apply movement
    def move(self,direction:tuple): 
        i0,j0=self.find0()
        i1,j1=i0+direction[0],j0+direction[1]
        #new_state=State(self.size,self.board.copy(),self.g_step)
        new_state=copy.deepcopy(self)
        if 0<=i1<self.size[0] and 0<=j1<self.size[1]:
            new_state.board[i1][j1],new_state.board[i0][j0]=new_state.board[i0][j0],new_state.board[i1][j1]
            new_state.g_step+=1
            new_state.get_f_step()
            #new_state.route=self.route.copy()
            new_state.route.append(direction)
            return new_state
        return None
    
    # judge whether success is reached
    def isSuccess(self):
        return self.get_h_step()==0

'''
initial=State(3,[[1,2,3],[4,5,6],[7,0,8]],0)
next=initial.move((0,1))
print(next.isSuccess())
print(next.route)
'''

#print(State(3,[[2,3,4],[5,6,7],[8,1,0]],0).get_goal_state())