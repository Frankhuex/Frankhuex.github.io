Klotski Game for SC1015 Lab 8
Tutorial Group: FCCA Team 2
Members: Hu Han, Lai Yi, Zhu Xinuo

How to play:
1. open main.py
2. Five variables can be modified: 
    size, board, algorithm, depth_limit_option, depth
3. run
4. you can use your mouse to mess up the board
5. by pressing SPACE on your keyboard, the AI agent begins to solve the puzzle you prepare for her.
