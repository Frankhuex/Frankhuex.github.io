import numpy as np
import pygame
from pygame.locals import *
import time
import copy

from State import State
from Queue import Queue
from Stack import Stack
from Const import *


class Solver:
    def __init__(self,size,board):
        self.init_state=State(size,board,0)
        self.size=self.init_state.size
        #self.unvisited_states=Stack()
        #self.visited_states=set()
        self.visited_boards=set()
        self.success_states=[]
    
    # Player messes up the board in this method
    def mess_state(self,screen,clock,myfont,run):
        directions=[(0,1),(0,-1),(1,0),(-1,0)]
        while run[0]:
            screen.fill((0,0,0))
            self.draw_board(self.init_state,screen,myfont)
            pygame.display.update()
            clock.tick(FPS)
            for event in pygame.event.get():
                if event.type==QUIT:
                    run[0]=False
                    return 
                elif event.type==MOUSEBUTTONDOWN:
                    i0,j0=self.init_state.find0()
                    for di,dj in directions:
                        i1,j1=i0+di,j0+dj
                        if 0<=i1<self.size[0] and 0<=j1<self.size[1]:
                            if Solver.is_focused_block(i1,j1):
                                self.init_state.board[i0][j0],self.init_state.board[i1][j1]=self.init_state.board[i1][j1],self.init_state.board[i0][j0]
                elif event.type==KEYDOWN:
                    if event.key==K_SPACE:
                        self.__init__(self.size,self.init_state.board)
                        return

    # AI solves the puzzle in this method
    def solution_state(self,screen,clock,myfont,run,algorithm,depth_limit_option,depth=-1):
        if not run[0]:
            return
        
        if depth_limit_option=="IDS":
            start_time=time.time()
            for d in range(1,depth+1):
                self_copy=copy.deepcopy(self)
                result=self_copy.solution_state(screen,clock,myfont,run,algorithm,"DLS",d)
                if result is not None:
                    self.init_state.board=State.generate_goal_board(self.size)
                    end_time=time.time()
                    print(f"Total time: {round(end_time-start_time,2)} seconds")
                    return result
            return None

        directions=[(0,1),(0,-1),(1,0),(-1,0)]

        # Only BFS & UCS use a queue, while others use a stack
        if algorithm=="BFS" or algorithm=="UCS":
            self.unvisited_states=Queue()
        else:
            self.unvisited_states=Stack()

        self.unvisited_states.push(self.init_state)
        start_time=time.time()
        while not self.unvisited_states.isEmpty() and run[0]:
            
            current_state=self.unvisited_states.pop()
            #print(current_state.f_step)
            
            # Depth limit is only effective in DLS
            if depth_limit_option=="DLS":
                if current_state.g_step>depth:
                    continue
            
            screen.fill((0,0,0))
            self.draw_board(current_state,screen,myfont)
            pygame.display.update()
            clock.tick(FPS)
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    run[0]=False
                    return 
                elif event.type==KEYDOWN:
                    if event.key==K_SPACE:
                        return        

            if current_state.isSuccess():
                self.success_states.append(current_state)
                break

            self.add_visited_board(current_state)
            #print(current_state.g_step)

            new_states=[]
            for d in directions:
                #print(d)
                new_state=current_state.move(d)
                if new_state is not None:
                    '''
                    if new_state.isSuccess():
                        self.success_states.append(new_state)
                        if new_state.g_step==1:
                            break
                    '''
                    if not self.is_visited_state(new_state):
                        new_states.append(new_state)
            
            # Astar & Greedy affects the sequence of pushing childnodes
            if algorithm=="A*":
                new_states=sorted(new_states,key=lambda i:i.f_step,reverse=True)
            elif algorithm=="Greedy":
                new_states=sorted(new_states,key=lambda i:i.h_step,reverse=True)

            for s in new_states:
                self.unvisited_states.push(s)
        
        # Solution output
        end_time=time.time()
        if depth_limit_option=="DLS":    
            print(f"Time of depth {depth}: {round(end_time-start_time,3)} seconds")
        else:
            print(f"Time: {round(end_time-start_time,3)} seconds")
        if len(self.success_states)>0:
            self.success_states=sorted(self.success_states,key=lambda i:i.g_step)
            min_step_st=self.success_states[0]
            print("Steps: ",min_step_st.g_step)
            print("Route: ",min_step_st.route)
            self.init_state=min_step_st
            return min_step_st
        else:
            print("No solution")
            return None


    # Followings are functional methods

    def mouse():
        return pygame.mouse.get_pos()

    def is_focused_block(i,j):
        if j*BLOCK_WID<Solver.mouse()[0]<(j+1)*BLOCK_WID:
            if i*BLOCK_WID<Solver.mouse()[1]<(i+1)*BLOCK_WID:
                return True
        return False

    def add_visited_board(self,state):
        self.visited_boards.add(tuple(map(tuple,state.board)))

    def is_visited_state(self,state):
        return tuple(map(tuple,state.board)) in self.visited_boards
    
    def draw_board(self,state,screen,myfont):
        for i in range(1,self.size[1]+1):
            pygame.draw.line(screen,LINE_COLOR,(0,i*BLOCK_WID),(self.size[1]*BLOCK_WID,i*BLOCK_WID))
        for j in range(1,self.size[0]+1):
            pygame.draw.line(screen,LINE_COLOR,(j*BLOCK_WID,0),(j*BLOCK_WID,self.size[0]*BLOCK_WID))

        for i in range(self.size[0]):
            for j in range(self.size[1]):
                n=state.board[i][j]
                if n==0:
                    continue
                block_x=j*BLOCK_WID+BLOCK_MARGIN
                block_y=i*BLOCK_WID+BLOCK_MARGIN
                block_wid=BLOCK_WID-2*BLOCK_MARGIN
                if Solver.is_focused_block(i,j):
                    pygame.draw.rect(screen,light(BLOCK_COLOR),(block_x,block_y,block_wid,block_wid),border_radius=BORDER_RADIUS)
                else:
                    pygame.draw.rect(screen,BLOCK_COLOR,(block_x,block_y,block_wid,block_wid),border_radius=BORDER_RADIUS)
                text_image=myfont.render(str(n),True,TEXT_COLOR)
                text_x=j*BLOCK_WID+BLOCK_WID/2-text_image.get_width()/2
                text_y=i*BLOCK_WID+BLOCK_WID/2-text_image.get_height()/2
                screen.blit(text_image,(text_x,text_y))

