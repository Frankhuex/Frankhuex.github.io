class Queue:
    def __init__(self,list=[]):
        self.list=list
    def push(self,value):
        self.list.append(value)
    def pop(self):
        if not self.isEmpty():
            return self.list.pop(0)
        return None
    def peek(self):
        if not self.isEmpty():
            return self.list[-1]
        return None
    def isEmpty(self):
        return len(self.list)==0