import pygame
import time
import json

from Const import *
from Note import *

class Gamerunner:
    def __init__(
            self,path,speed,fps,
            screen_wid,screen_hei,
            track_wid,track_num,
            judge_line,appear_line,
            strict
            ):
        self.path=path
        self.speed=speed
        self.fps=fps
        self.screen_wid=screen_wid
        self.screen_hei=screen_hei
        self.track_wid=track_wid
        self.track_num=track_num
        self.judge_line=judge_line
        self.appear_line=appear_line
        self.strict=strict

        self.track_left=self.screen_wid/2-self.track_wid/2
        self.track_perwid=self.track_wid/self.track_num

        self.readfile()
    def readfile(self):
        with open(self.path,'r+') as f:
            self.jsdata=json.load(f)
        self.fall_time=(self.judge_line-self.appear_line)/self.speed
        self.song_path="songs/"+self.jsdata["title"]
        self.notelist=[]
        secondperbeat=60/self.jsdata["bpm"]
        for beat in self.jsdata["notes"]:
            for frac in self.jsdata["notes"][beat]:
                frac_list=frac.split('/')
                if len(frac_list)==1:
                    frac_time=float(frac_list[0])
                else:
                    frac_time=float(frac_list[0])/float(frac_list[1])
                judgetime=self.jsdata["offset"]+(float(beat[4:])+frac_time)*secondperbeat
                appeartime=judgetime-self.fall_time
                for track in self.jsdata["notes"][beat][frac]:
                    tracknum=int(track[5:])
                    x=self.track_left+tracknum*self.track_perwid
                    new_note=Note(appeartime,judgetime,tracknum,self.speed,x,self.appear_line,self.track_perwid,5,False)
                    self.notelist.append(new_note)
    def draw_judgeline(self,screen):
        pygame.draw.line(screen,WHITE,(0,self.judge_line),(self.screen_wid,self.judge_line),5)
    def draw_judgerange(self,screen):
        pygame.draw.rect(screen,YELLOW,(0,self.judge_line-self.strict,self.screen_wid,2*self.strict))
    def draw_track(self,screen):
        for i in range(5):
            pygame.draw.line(screen,WHITE,(self.track_left+i*self.track_perwid,0),(self.track_left+i*self.track_perwid,self.judge_line),5)

    def rungame(self,run,screen,clock):
        pygame.mixer.music.load(self.song_path)
        pygame.mixer.music.play()
        start_time=time.time()
        while run[0]:
            screen.fill(BLACK)
            self.draw_judgerange(screen)
            self.draw_track(screen)
            self.draw_judgeline(screen)
            past_time=time.time()-start_time
            #print(past_time)
            for note in self.notelist:  
                if abs(note.appear_time-past_time)<0.01:
                    note.visible=True
                if note.visible:
                    note.move(self.fps)
                    note.draw(screen,GREEN)
                    if note.y-self.judge_line>self.strict or note.y>self.screen_hei:
                        note.visible=False
                        self.notelist.remove(note)
                        print("Miss")
            
            
            pygame.display.update()
            clock.tick(self.fps)
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    run[0]=False
                
                    
                for note in self.notelist:
                    if abs(note.y-self.judge_line)<self.strict:
                        if event.type==pygame.KEYDOWN:
                            if event.key==TRACK_KEY[note.track]: 
                                print("Good")
                                note.visible=False
                                self.notelist.remove(note)




        
    
    