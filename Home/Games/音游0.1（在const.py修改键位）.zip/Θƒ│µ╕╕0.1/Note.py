import pygame
from Const import *
class Note:
    def __init__(self,appear_time,judge_time,track,speed,x,y,wid,hei,visible):
        self.x=x
        self.y=y
        self.appear_time=appear_time
        self.judge_time=judge_time
        self.track=track
        self.speed=speed
        self.wid=wid
        self.hei=hei
        self.visible=visible
    def move(self,fps):
        # speed=pixel/second
        self.y+=self.speed/fps
    def draw(self,screen,color):
        if self.visible:
            pygame.draw.rect(screen,color,(self.x,self.y,self.wid,self.hei))
            pygame.draw.rect(screen,WHITE,(self.x,self.y,self.wid,self.hei),1)
    def printinfo(self):
        print(self.x,self.y,self.track,self.appear_time,self.judge_time,self.speed,self.wid,self.hei,self.visible)

