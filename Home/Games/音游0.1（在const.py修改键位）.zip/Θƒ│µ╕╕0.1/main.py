import pygame
import time
pygame.init()
from Gamerunner import *

screen=pygame.display.set_mode((SCREEN_WID,SCREEN_HEI))
pygame.display.set_caption("MUG")
clock=pygame.time.Clock()

g1=Gamerunner('charts/chart1.json',SPEED,FPS,SCREEN_WID,SCREEN_HEI,TRACK_WID,TRACK_NUM,JUDGE_LINE,APPEAR_LINE,STRICT)

print(g1.jsdata)
for i in g1.notelist:
    i.printinfo()

g1.rungame([True],screen,clock)
