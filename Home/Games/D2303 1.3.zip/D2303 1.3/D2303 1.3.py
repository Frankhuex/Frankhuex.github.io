import pygame
from pygame.locals import *
import pymunk
import pymunk.pygame_util
import pymunk.vec2d
import os
pygame.init()

screen_width=1200
screen_height=800

fps=120



screen=pygame.display.set_mode((screen_width,screen_height))
clock=pygame.time.Clock()
white=(255,255,255)
black=(0,0,0)
blue=(0,50,100)
light_blue=(40,90,140)

run=True

def mousepos():
    return pygame.mouse.get_pos()

def proportional_pos(m,n): 
    return (int(screen_width*m),int(screen_height*n))

def mod(v):
    return (v[0]**2+v[1]**2)**0.5



#标准按钮：文字内容，汉字数量，文字颜色，x坐标占比，y坐标占比，是否是按钮，指向页面(无则None)
class std_rect(object):
    def __init__(self,content,hanzi_num,text_color,m,n,isButton,toWhere):
        self.content=content
        self.text_color=text_color
        self.m=m
        self.n=n
        self.isButton=isButton        
        self.toWhere=toWhere
        self.hei=40             
        
        self.refresh()
        
    def refresh(self):
        myfont=pygame.font.Font("Fonts/cmdysj.ttf",int(self.hei*(1/2)))
        textImage=myfont.render(self.content,True,self.text_color)
        self.text_wid=textImage.get_width()  

        self.wid=self.text_wid+self.hei/2

        center_pos=proportional_pos(self.m,self.n)
        self.pos=(int(center_pos[0]-self.wid/2),int(center_pos[1]-self.hei/2))


    def if_focused(self):
        if self.pos[0]<=mousepos()[0]<=self.pos[0]+self.wid:
            if self.pos[1]<=mousepos()[1]<=self.pos[1]+self.hei:
                return True
    
    def draw(self):
        myfont=pygame.font.Font("fonts/cmdysj.ttf",int(self.hei*(1/2)))
        textImage=myfont.render(self.content,True,self.text_color)
        
        if self.isButton:
            if self.if_focused():
                pygame.draw.rect(screen,light_blue, (self.pos[0], self.pos[1], self.wid, self.hei))
            else:
                pygame.draw.rect(screen,blue, (self.pos[0], self.pos[1], self.wid, self.hei))

        screen.blit(textImage, (self.pos[0]+self.hei/4, self.pos[1]+self.hei/4))



#音乐全局变量
audio_path="Audio/"
music_list=[im for im in os.listdir(audio_path) if (im.endswith(".wav") or (im.endswith(".mp3")))]
music_index=0
controller_list=[
    std_rect("已暂停",3,black,1/2,2/5,False,None),
    std_rect(music_list[music_index],len(music_list[music_index]),black,1/2,3/5,False,None),
    std_rect("上一首",3,white,3/8,4/5,True,None),
    std_rect("播放",3,white,1/2,4/5,True,None),
    std_rect("下一首",3,white,5/8,4/5,True,None)
]
current_music=audio_path+controller_list[1].content    
pygame.mixer.music.load(current_music)
started=False
SONGEND=pygame.USEREVENT+1
pygame.mixer.music.set_endevent(SONGEND)

#music
def music():
    global run
    global music_index
    global current_music
    global started
    tr_list=[]
    tr_list.append(std_rect("返回",4,white,1/6,1/6,True,"teacher_desk"))    
    controller_list[1].refresh()
    while run:       
        screen.fill(white)
        for member in tr_list+controller_list:
            member.draw()   
        pygame.display.update()
        clock.tick(30)
        for event in pygame.event.get():
            if event.type==SONGEND:
                music_index+=1
                if music_index==len(music_list):
                    music_index=0
                controller_list[1].content=music_list[music_index]
                current_music=audio_path+controller_list[1].content    
                pygame.mixer.music.load(current_music)
                pygame.mixer.music.play()
            elif event.type==QUIT:
                run=False
                pygame.quit()
            elif event.type==MOUSEBUTTONUP:
                for tr in tr_list:
                    if tr.isButton:
                        if tr.if_focused():
                            return tr.toWhere   
                
                #播放/暂停
                if controller_list[3].if_focused():                    
                    #未开播则开播
                    if started==False:
                        pygame.mixer.music.play()
                        controller_list[0].content="播放中"
                        controller_list[3].content="暂停"
                        started=True  
                    #已开播则调节播放/暂停
                    else:
                        if pygame.mixer.music.get_busy():
                            pygame.mixer.music.pause()
                            controller_list[0].content="已暂停"
                            controller_list[3].content="播放" 
                        else:
                            pygame.mixer.music.unpause()   
                            controller_list[0].content="播放中"
                            controller_list[3].content="暂停"                           

                #上一首
                elif controller_list[2].if_focused():
                    music_index-=1
                    if music_index==-1:
                        music_index=len(music_list)-1                                        
                    controller_list[1].content=music_list[music_index]
                    controller_list[1].refresh()
                    current_music=audio_path+controller_list[1].content
                    pygame.mixer.music.load(current_music)
                    started=False
                    if controller_list[0].content=="播放中":
                        pygame.mixer.music.play() 
                        started=True
                #下一首
                elif controller_list[4].if_focused():
                    music_index+=1
                    if music_index==len(music_list):
                        music_index=0                                    
                    controller_list[1].content=music_list[music_index]
                    controller_list[1].refresh()
                    current_music=audio_path+controller_list[1].content
                    pygame.mixer.music.load(current_music)
                    started=False
                    if controller_list[0].content=="播放中":
                        pygame.mixer.music.play() 
                        started=True          



def loop_page(tr_list,image_or_path):
    global run
    global music_index
    global current_music
    global started
    iop_type=None
    if image_or_path!=None:
        if image_or_path.endswith("/"):
            iop_type="path"
            path=image_or_path
            bg_list=[im for im in os.listdir(path) if (im.endswith(".jpg") or (im.endswith(".png")))]
            picture_index=0
            bg=pygame.image.load(path+bg_list[picture_index]) 
        else:
            iop_type="image"
            bg=pygame.image.load(image_or_path)
    while run:       
        screen.fill(white)
        if iop_type!=None:            
            screen.blit(bg,(0,0))
        for member in tr_list:
            member.draw()   
        pygame.display.update()
        clock.tick(30)
        for event in pygame.event.get():
            if event.type==SONGEND:
                music_index+=1
                if music_index==len(music_list):
                    music_index=0
                controller_list[1].content=music_list[music_index]
                current_music=audio_path+controller_list[1].content    
                pygame.mixer.music.load(current_music)
                pygame.mixer.music.play()            
            elif event.type==QUIT:
                run=False
                pygame.quit()
            elif event.type==MOUSEBUTTONUP:
                for tr in tr_list:
                    if tr.isButton:
                        if tr.if_focused():
                            return tr.toWhere
                else:
                    if iop_type=="path":
                        picture_index=(picture_index+1)%len(bg_list)
                        bg=pygame.image.load(path+bg_list[picture_index])     



#welcome
def welcome():
    global run
    global music_index
    global current_music
    global started
    pygame.mixer.music.set_volume(0)
    tr_list=[]
    tr_list.append(std_rect("进入三班",4,white,1/2,4/5,True,"D2303"))
    tr_list.append(std_rect("欢迎来到效实！",6,white,1/2,2/5,False,None))
    return loop_page(tr_list,"Images/Xiaoshi.jpg")

#D2303
def D2303():
    global run
    global music_index
    global current_music
    global started
    pygame.mixer.music.set_volume(1)
    tr_list=[]
    tr_list.append(std_rect("教室后墙",4,white,1/6,1/2,True,"backwall"))
    tr_list.append(std_rect("黑板",4,white,5/6,1/2,True,"board"))
    tr_list.append(std_rect("走出教室",4,white,1/2,4/5,True,"welcome"))
    tr_list.append(std_rect("讲台桌",4,white,5/6,1/6,True,"teacher_desk"))
    return loop_page(tr_list,None)  

#backwall
def backwall():
    global run
    global music_index
    global current_music
    global started
    tr_list=[]
    tr_list.append(std_rect("返回",4,white,1/6,1/6,True,"D2303"))
    tr_list.append(std_rect("立瓶子",4,white,1/6,2/6,True,"bottle"))
    return loop_page(tr_list,"Images/Backwall/")
    
    
    '''
    path="Images/Appreciate/"
    bg_list=[im for im in os.listdir(path) if (im.endswith(".jpg") or (im.endswith(".png")))]
    picture_index=0
    bg=pygame.image.load(path+bg_list[picture_index])    
    
    while run:       
        screen.fill(white)
        screen.blit(bg,(0,0))
        for member in tr_list:
            member.draw()   
        pygame.display.update()
        clock.tick(30)
        for event in pygame.event.get():
            if event.type==SONGEND:
                music_index+=1
                if music_index==len(music_list):
                    music_index=0
                controller_list[1].content=music_list[music_index]
                current_music=audio_path+controller_list[1].content    
                pygame.mixer.music.load(current_music)
                pygame.mixer.music.play()
            elif event.type==QUIT:
                run=False
                pygame.quit()
            elif event.type==MOUSEBUTTONDOWN:
                for tr in tr_list:
                    if tr.isButton:
                        if tr.if_focused():
                            return tr.toWhere
                else:
                    picture_index=(picture_index+1)%len(bg_list)
                    bg=pygame.image.load(path+bg_list[picture_index])         
    '''

#bottle
def bottle():
    global run
    global music_index
    global current_music
    global started
    tr_list=[]
    tr_list.append(std_rect("返回",4,white,1/6,1/6,True,"backwall"))
    tr_list.append(std_rect("启动！",3,white,1/2,4/5,True,"standing_bottle"))
    tr_list.append(std_rect("立瓶子",4,white,1/2,1/2,False,None))
    return loop_page(tr_list,"Images/Bottle.jpg")

def init_bottle(space,h_low,h_mid,h_top,r_big,r_small):
    body1=pymunk.Body(body_type=pymunk.Body.STATIC)
    body1.position=(600,400)
    chamfer=5
    vertices=[
        (-r_big+chamfer,h_low),(-r_big,h_low-chamfer),(-r_big,-h_mid),(-r_small,-(h_mid+h_top)),
        (r_big-chamfer,h_low),(r_big,h_low-chamfer),(r_big,-h_mid),(r_small,-(h_mid+h_top))
    ]
    bott=pymunk.Poly(body1,vertices)
    bott.mass=100
    bott.color=(0,100,205,0)
    bott.elasticity = 0.4 
    bott.friction = 0.8 
    space.add(body1, bott)
    return bott

#standing_bottle
def standing_bottle():
    global run
    global music_index
    global current_music
    global started
    tr_list=[]
    tr_list.append(std_rect("返回",4,white,1/6,1/6,True,"bottle"))
    tr_list.append(std_rect("0/0",3,black,1/2,1/6,False,None))
    
    #space
    space=pymunk.Space()
    space.gravity=(0,1600)
    draw_options=pymunk.pygame_util.DrawOptions(screen)
    dt=1/30
    
    #瓶子
    h_low=40
    h_mid=80
    h_top=40
    r_big=30
    r_small=15
    bott=init_bottle(space,h_low,h_mid,h_top,r_big,r_small)

    #地板
    y_ground=600
    depth=10
    body2=pymunk.Body(body_type=pymunk.Body.STATIC)
    body2.position=(screen_width/2,y_ground)
    ground=pymunk.Poly.create_box(body2,(screen_width,depth))
    ground.elasticity = 0.8
    ground.friction = 0.8
    space.add(body2, ground)
    #是否抓着
    grab=False
    grabbed_pos=None
    #是否扔出
    thrown=False

    while run:       
        screen.fill(white)
        for member in tr_list:
            member.draw()           
        space.debug_draw(draw_options)    
        #抓着时
        if grab:
            pygame.draw.line(screen,black,grabbed_pos,mousepos())
        #扔出时
        if thrown:
            if bott.body.position[1]>400 and mod(bott.body.velocity)<1:
                content=tr_list[1].content
                list=content.split('/')
                list[1]=str(int(list[1])+1)
                tr_list[1].content=list[0]+'/'+list[1]
                #判断落地
                if y_ground-depth/2-(h_mid+h_top)-10<bott.body.position[1]<y_ground-depth-h_low+10:
                    list[0]=str(int(list[0])+1)
                    tr_list[1].content=list[0]+'/'+list[1]
                #落地后重置瓶子后设为没扔出
                space.remove(bott,bott.body)
                bott=init_bottle(space,h_low,h_mid,h_top,r_big,r_small)
                thrown=False

        pygame.display.update()
        space.step(dt)
        clock.tick(30)

        for event in pygame.event.get():
            if event.type==SONGEND:
                music_index+=1
                if music_index==len(music_list):
                    music_index=0
                controller_list[1].content=music_list[music_index]
                current_music=audio_path+controller_list[1].content    
                pygame.mixer.music.load(current_music)
                pygame.mixer.music.play()    
            elif event.type==QUIT:
                run=False
                pygame.quit()
            elif event.type==MOUSEBUTTONUP:
                for tr in tr_list:
                    if tr.isButton:
                        if tr.if_focused():
                            return tr.toWhere  
                #抓着时点击来扔出
                if grab:
                    thrown=True
                    bott.body.body_type = pymunk.Body.DYNAMIC
                    fx=50*(mousepos()[0]-grabbed_pos[0])
                    fy=150*(mousepos()[1]-grabbed_pos[1])
                    bott.body.apply_impulse_at_local_point((fx,fy),(grabbed_pos[0]-600,grabbed_pos[1]-400)) 
                    grab=False 
            elif event.type==MOUSEBUTTONDOWN:
                #没抓着、且没扔出时点击，才可以抓住
                if not grab and not thrown:
                    grab=True
                    grabbed_pos=mousepos()                

#board
def board():
    global run
    global music_index
    global current_music
    global started
    tr_list=[]
    tr_list.append(std_rect("返回",4,white,1/6,1/6,True,"D2303"))
    return loop_page(tr_list,"Images/Board/")
   

#teacher_desk
def teacher_desk():
    global run
    global music_index
    global current_music
    global started
    tr_list=[]
    tr_list.append(std_rect("返回",4,white,1/6,1/6,True,"D2303"))
    tr_list.append(std_rect("放歌",3,white,1/2,4/5,True,"music"))
    return loop_page(tr_list,None) 


def cutscene():
    for i in range(256):
        pass

def run_scene(scene):
    if scene=="welcome":
        scene=welcome()
    elif scene=="D2303":
        scene=D2303()
    elif scene=="backwall":
        scene=backwall()
    elif scene=="bottle":
        scene=bottle()
    elif scene=="standing_bottle":
        scene=standing_bottle()
    elif scene=="board":
        scene=board()
    elif scene=="teacher_desk":
        scene=teacher_desk()
    elif scene=="music":
        scene=music()
    return scene

def main():
    global run
    scene="welcome"
    while run:
        scene=run_scene(scene)

main()