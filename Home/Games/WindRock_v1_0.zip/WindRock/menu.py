import pygame
from pygame.locals import *
from Const import *
from Text import *
from good import get_txts,good
import os
import random
from show_record import show_record

def menu(run,screen,clock):
    bad_files=os.listdir('records/bad')
    bad_records=[file for file in bad_files if file.endswith(".txt")]
    bad_record_index=0

    texts=[None]*3
    texts[0]=Text(content="风石",yrate=0.4)
    texts[1]=Button(content="按序查看好事",yrate=0.5)
    texts[2]=Button(content="随机查看坏事",yrate=0.6)
    while run[0]:
        screen.fill(BLACK)
        Button.draw_all(texts,screen,SCREEN_WID,SCREEN_HEI)
        pygame.display.update()
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                run[0]=False
                return
            elif event.type==MOUSEBUTTONDOWN:
                if texts[1].focused():
                    good(run,screen,clock)
                elif texts[2].focused():
                    if bad_record_index==len(bad_records):
                        bad_record_index=0
                        random.shuffle(bad_records)
                    show_record(run,screen,clock,'records/bad',bad_records[bad_record_index])
                    bad_record_index+=1
                
            