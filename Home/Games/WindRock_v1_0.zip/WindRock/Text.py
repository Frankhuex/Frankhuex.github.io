import pygame
from pygame.locals import *
from Const import *
pygame.init()

class Text:
    def __init__(self,content,xrate=0.5,yrate=0.5,text_hei=BUTTON_HEI,font_path="font/cmdysj.ttf",text_color=WHITE):
        self.content=content
        self.xrate=xrate
        self.yrate=yrate
        self.color=text_color
        self.text_hei=int(text_hei)
        self.font_path=font_path
        self.font=pygame.font.Font(font_path,self.text_hei)
        self.textImage=self.font.render(self.content,True,self.color)
        self.wid,self.hei=self.textImage.get_size()
    def draw(self,screen,screen_wid,screen_hei):
        self.x=screen_wid*self.xrate-self.wid/2
        self.y=screen_hei*self.yrate-self.hei/3
        screen.blit(self.textImage,(self.x,self.y))
    def refreshContent(self,new_content):
        self.content=new_content
        self.font=pygame.font.Font(self.font_path,self.text_hei)
        self.textImage=self.font.render(self.content,True,self.color)
        self.wid,self.hei=self.textImage.get_size()
class Button:
    def __init__(self,content,xrate=0.5,yrate=0.5,button_wid=BUTTON_WID,button_hei=BUTTON_HEI,font_path="font/cmdysj.ttf",text_color=WHITE,button_color=BLUE):
        self.text=Text(content,xrate,yrate,button_hei/2,font_path,text_color)
        self.xrate=xrate
        self.yrate=yrate
        self.button_wid=button_wid
        self.button_hei=button_hei
        self.button_color=button_color
        self.button_x=SCREEN_WID*self.xrate-button_wid/2
        self.button_y=SCREEN_HEI*self.yrate-button_hei/2

    def focused(self):
        if self.button_x<=mouse()[0]<=self.button_x+self.button_wid:
            if self.button_y<=mouse()[1]<=self.button_y+self.button_hei:
                return True
        return False
    def draw(self,screen,screen_wid,screen_hei):
        if self.focused():
            color=light(self.button_color)
        else:
            color=self.button_color
        pygame.draw.rect(screen,color,(self.button_x,self.button_y,self.button_wid,self.button_hei))
        self.text.draw(screen,screen_wid,screen_hei)

    def draw_all(list,screen,screen_wid,screen_hei):
        for i in list:
            i.draw(screen,screen_wid,screen_hei)
