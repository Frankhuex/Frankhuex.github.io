import pygame
from pygame.locals import *
from Const import *
from menu import *
from Text import *
import os
import copy

def record_lines(lines):
    records=[]
    count=0
    page_index=0
    for line in lines:
        if count==LINES_PER_PAGE:
            page_index+=1
            count=0
        if count==0:
            records.append([])
        records[page_index].append(Text(content=line,yrate=(count+4)/(LINES_PER_PAGE+7),text_hei=BUTTON_HEI/2,text_color=WHITE))
        count+=1
    return records

def show_record(run,screen,clock,path,file):
    lines=[]
    with open(os.path.join(path,file),"r",encoding="UTF-8") as f:
        lines=f.readlines()
    if len(lines)>0:
        records=record_lines(lines)
    else:
        records=record_lines(["Empty"])

    page_index=0
    page_number=len(records)

    texts=[None]*5
    texts[0]=Button(content="上一页",xrate=1/4.45,yrate=7/8)
    texts[1]=Button(content="下一页",xrate=3.45/4.45,yrate=7/8)
    texts[2]=Text(content=f"{page_index+1}/{page_number}",xrate=1/2,yrate=7/8,text_hei=BUTTON_HEI/2)
    texts[3]=Text(content=file[:-4],xrate=1/2,yrate=1/8)
    texts[4]=Button(content="返回",xrate=1/4.45,yrate=1/8)

    while run[0]:
        screen.fill(BLACK)
        Button.draw_all(records[page_index]+texts,screen,SCREEN_WID,SCREEN_HEI)
        pygame.display.update()
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                run[0]=False
                return
            elif event.type==MOUSEBUTTONDOWN:
                if texts[0].focused():
                    page_index=(page_index-1)%page_number
                    texts[2].refreshContent(f"{page_index+1}/{page_number}")
                elif texts[1].focused():
                    page_index=(page_index+1)%page_number
                    texts[2].refreshContent(f"{page_index+1}/{page_number}")
                elif texts[4].focused():
                    return


