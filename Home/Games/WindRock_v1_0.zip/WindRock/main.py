import pygame
from pygame.locals import *
from Const import *
from menu import *
from good import *
from show_record import *
pygame.init()

screen=pygame.display.set_mode((SCREEN_WID,SCREEN_HEI))
pygame.display.set_caption("WindRock")
clock=pygame.time.Clock()

dict={
    "menu":menu,
    "good":good
}


def main():
    run=[True]
    #menu(run,screen,clock)
    menu(run,screen,clock)
    pygame.quit()

main()