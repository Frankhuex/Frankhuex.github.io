import pygame
from pygame.locals import *

FPS=30
SCREEN_WID=800
SCREEN_HEI=600
BUTTON_HEI=50
BUTTON_WID=200

WHITE=(255,255,255)
BLACK=(0,0,0)
BLUE=(0,50,100)
GREY=(210,210,210)

RECORDS_PER_PAGE=5
LINES_PER_PAGE=10

def light(color):
    r=color[0]+100 if color[0]<155 else 255
    g=color[1]+100 if color[1]<155 else 255
    b=color[2]+100 if color[2]<155 else 255
    return (r,g,b)

def mouse():
    return pygame.mouse.get_pos()