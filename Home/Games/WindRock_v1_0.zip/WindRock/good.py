import pygame
from pygame.locals import *
from Const import *
from menu import *
from Text import *
import os
import copy
from show_record import show_record

def get_txts(path):
    files = os.listdir(path)
    files.sort()
    txt_table={}
    for file in files:
        if file.endswith(".txt"):
            with open(os.path.join(path,file),"r",encoding="UTF-8") as f:
                lines=f.readlines()
                if len(lines)>0:
                    txt_table[file[:-4]]=lines
                else:
                    txt_table[file[:-4]]=['Empty']
    return txt_table

def record_buttons(txt_table):
    records=[]
    count=0
    page_index=0
    for txt in txt_table:
        if count==RECORDS_PER_PAGE:
            page_index+=1
            count=0
        if count==0:
            records.append([])
        file_lines=txt_table[txt]
        file_title=file_lines[0] if len(file_lines)>0 else ''
        content=txt+': '+file_title
        records[page_index].append(Button(content=content,yrate=(count+2)/(RECORDS_PER_PAGE+3),button_wid=SCREEN_WID*0.8,button_color=GREY,text_color=BLACK))
        count+=1
    return records

def good(run,screen,clock):
    txt_table=get_txts("records/good")
    records=record_buttons(txt_table)

    page_index=0
    page_number=len(records)

    texts=[None]*5
    texts[0]=Button(content="上一页",xrate=1/4.45,yrate=7/8)
    texts[1]=Button(content="下一页",xrate=3.45/4.45,yrate=7/8)
    texts[2]=Text(content=f"{page_index+1}/{page_number}",xrate=1/2,yrate=7/8,text_hei=BUTTON_HEI/2)
    texts[3]=Text(content="好事",xrate=1/2,yrate=1/8)
    texts[4]=Button(content="返回",xrate=1/4.45,yrate=1/8)
    while run[0]:
        screen.fill(BLACK)
        Button.draw_all(records[page_index]+texts,screen,SCREEN_WID,SCREEN_HEI)
        pygame.display.update()
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                run[0]=False
                return
            elif event.type==MOUSEBUTTONDOWN:
                if texts[0].focused():
                    page_index=(page_index-1)%page_number
                    texts[2].refreshContent(f"{page_index+1}/{page_number}")
                elif texts[1].focused():
                    page_index=(page_index+1)%page_number
                    texts[2].refreshContent(f"{page_index+1}/{page_number}")
                elif texts[4].focused():
                    return
                for re in records[page_index]:
                    if re.focused():
                        show_record(run,screen,clock,'records/good',re.text.content.split(':')[0]+'.txt')
