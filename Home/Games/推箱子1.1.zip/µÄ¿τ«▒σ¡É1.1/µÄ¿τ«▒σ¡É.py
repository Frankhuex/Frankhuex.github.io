import pygame
from pygame.locals import *
import os
import sys
pygame.init()

fps=120
run=True

screen_wid=1200
screen_hei=800
block_wid=60
unit_pixel=block_wid/14
hei = int(block_wid / 2)

X0=(screen_wid-16*block_wid)/2
Y0=(screen_hei-9*block_wid)/2

screen=pygame.display.set_mode((screen_wid,screen_hei))
clock=pygame.time.Clock()

myfont=pygame.font.Font("Fonts/cmdysj.ttf",int(block_wid/1.5))
font_button=pygame.font.Font("Fonts/cmdysj.ttf",int((block_wid-4*unit_pixel)/1.5))


WHITE=(255,255,255)
BLACK=(0,0,0)

GREY=(200,200,200)
RED=(250,0,0)
YELLOW=(250,250,0)
BLUE=(0,0,250)
GREEN=(0,250,0)
PINK=(250,100,100)
PURPLE=(200,0,200)
matching_dict= {'A':'X','B':'Y'}

levels = [level[5:-4] for level in os.listdir("Levels") if (level.endswith(".txt") and "Level" in level)]
levels.sort()
designs = [level[6:-4] for level in os.listdir("Levels") if (level.endswith(".txt") and "Design" in level)]
designs.sort()


def mouse():
    return pygame.mouse.get_pos()

def dark(color):
    list=[0,0,0]
    for i in range(0,3):
        if color[i]>100:
            list[i]=color[i]-100
        else:
            list[i]=color[i]
    return (list[0],list[1],list[2])

def light(color):
    list=[0,0,0]
    for i in range(0,3):
        if color[i]<105:
            list[i]=color[i]+150
        else:
            list[i]=color[i]
    return (list[0],list[1],list[2])

def color_decoder(type):
    if type=='0':
        return GREY
    elif type=='!':
        return PURPLE
    elif type=='A':
        return BLUE
    elif type=='X':
        return light(BLUE)
    elif type=='B':
        return RED
    elif type=='Y':
        return light(RED)
    elif type=='_':
        return WHITE



class block(object):
    def __init__(self,type,row,col):
        self.type=type
        self.row=row
        self.col=col

        self.color=color_decoder(self.type)
        self.x=X0+block_wid*col
        self.y=Y0+block_wid*row
    def draw(self):
        pygame.draw.rect(screen, BLACK, (self.x+unit_pixel, self.y+unit_pixel, block_wid-unit_pixel, block_wid-unit_pixel))
        pygame.draw.rect(screen, self.color, (self.x+unit_pixel, self.y+unit_pixel, block_wid-2*unit_pixel, block_wid-2*unit_pixel))
        pygame.draw.rect(screen, WHITE, (self.x+unit_pixel, self.y+unit_pixel, block_wid-3*unit_pixel,unit_pixel))
        pygame.draw.rect(screen, WHITE, (self.x+unit_pixel, self.y+unit_pixel, unit_pixel, block_wid - 3 * unit_pixel))
        pygame.draw.rect(screen, dark(self.color), (self.x + 2*unit_pixel, self.y+block_wid-2*unit_pixel,block_wid-3*unit_pixel,unit_pixel))
        pygame.draw.rect(screen, dark(self.color), (self.x+block_wid-2*unit_pixel, self.y+2*unit_pixel,unit_pixel,block_wid-3*unit_pixel))

class button(object):
    def __init__(self,text,x,y,left="left"):
        self.text=text
        self.x=x
        self.y=y
        self.textImage = font_button.render(self.text, True, BLACK)
        self.wid=self.textImage.get_width()+8*unit_pixel
        if left=="right":
            self.x-=self.wid
    def focused(self):
        if self.x<=mouse()[0]<=self.x+self.wid and self.y<=mouse()[1]<=self.y+block_wid:
            return True
    def draw(self):
        pygame.draw.rect(screen, BLACK,(self.x + unit_pixel, self.y + unit_pixel, self.wid - unit_pixel, block_wid - unit_pixel))
        pygame.draw.rect(screen, WHITE, (self.x + unit_pixel, self.y + unit_pixel, self.wid - 2 * unit_pixel, block_wid - 2 * unit_pixel))
        pygame.draw.rect(screen, WHITE, (self.x + unit_pixel, self.y + unit_pixel, self.wid - 3 * unit_pixel, unit_pixel))
        pygame.draw.rect(screen, WHITE,(self.x + unit_pixel, self.y + unit_pixel, unit_pixel, block_wid - 3 * unit_pixel))
        pygame.draw.rect(screen, dark(WHITE), ( self.x + 2 * unit_pixel, self.y + block_wid - 2 * unit_pixel, self.wid - 3 * unit_pixel, unit_pixel))
        pygame.draw.rect(screen, dark(WHITE), ( self.x + self.wid - 2 * unit_pixel, self.y + 2 * unit_pixel, unit_pixel, block_wid - 3 * unit_pixel))
        screen.blit(self.textImage,(self.x+4*unit_pixel,self.y+3*unit_pixel))
        if self.focused():
            pygame.draw.rect(screen,YELLOW,(self.x,self.y,self.wid,block_wid),5)


y_button = screen_hei / 2 - 4.5 * block_wid - block_wid
button_menu = button("主菜单", screen_wid / 2 + 8 * block_wid, y_button, "right")
button_restart = button("重来", button_menu.x - unit_pixel, y_button, "right")
button_nextlevel=button("下一关",button_restart.x-unit_pixel,y_button,"right")

class text0(object):
    def __init__(self,content,hei,x,y,color=BLACK,left="left"):
        self.content=content
        self.hei=hei
        self.x=x
        self.y=y
        self.color=color
        self.font=pygame.font.Font("Fonts/cmdysj.ttf",hei)
        self.image=self.font.render(content, True, self.color)
        self.wid=self.image.get_width()
        if left=="right":
            self.x-=self.wid
    def draw(self):
        screen.blit(self.image,(self.x,self.y))
    def refresh(self):
        self.font = pygame.font.Font("Fonts/cmdysj.ttf", self.hei)
        self.image = self.font.render(self.content, True, self.color)
        self.wid = self.image.get_width()





def change(rc,dir):
    if dir=='right':
        return (rc[0],rc[1]+1)
    elif dir=='up':
        return (rc[0]-1,rc[1])
    elif dir=='left':
        return (rc[0],rc[1]-1)
    elif dir=='down':
        return (rc[0]+1,rc[1])



def move(blocks,buttons,texts,rc_dict,dir):
    global run
    moved=[] #可移动的方块本体
    passing=True
    for key in rc_dict:
        r,c=rc_dict[key]
        type=blocks[r][c].type
        r1,c1=change((r,c),dir)
        if 0<=r1<9 and 0<=c1<16:
            type1=blocks[r1][c1].type
        #判断是否即将过关
            if passing==True:
                if type1 != matching_dict[type]:
                    passing=False
            #判断目标位置是不是"_"，然后移动
            if type1=='_':
                blocks[r1][c1]=block(type,r1,c1)
                blocks[r][c]=block('_',r,c)
                rc_dict[key]=(r1,c1)
                moved.append((r1,c1))
        else:
            passing=False
    #若能过关则移动
    if passing:
        for key in rc_dict:
            r, c = rc_dict[key]
            type = blocks[r][c].type
            r1, c1 = change((r, c), dir)

            blocks[r1][c1] = block(type, r1, c1)
            blocks[r][c] = block('_', r, c)
            rc_dict[key] = (r1, c1)
            moved.append((r1, c1))

    #移方块动画
    rest_pixels=block_wid
    while rest_pixels>0:
        screen.fill(light(GREEN))
        for text in texts:
            text.draw()
        for butt in buttons:
            butt.draw()
        for row in range(9):
            for col in range(16):
                if blocks[row][col].type != '_' and blocks[row][col].type not in rc_dict:
                    blocks[row][col].draw()
                elif blocks[row][col].type in rc_dict:
                    if (row,col) not in moved:
                        blocks[row][col].draw()
                    else:
                        temp_block=block(blocks[row][col].type,row,col)
                        if dir=='right':
                            temp_block.x-=rest_pixels
                        elif dir=='up':
                            temp_block.y+=rest_pixels
                        elif dir=='left':
                            temp_block.x+=rest_pixels
                        elif dir=='down':
                            temp_block.y-=rest_pixels
                        temp_block.draw()
        rest_pixels-=unit_pixel
        pygame.display.update()
        clock.tick(fps)
        for event in pygame.event.get():
            if event.type==QUIT:
                run=False
                return None,None
    return len(moved)!=0,passing


def show_result(blocks,texts,step,max_steps,level):
    global run
    passing=True

    if max_steps=="不限":
        max_steps=99999
    else:
        max_steps=int(max_steps)

    # 按钮
    buttons = [button_menu,button_restart]


    if step <= max_steps:
        result = "过关！"
    elif max_steps < step <= 1.5 * max_steps:
        result = "勉强！"
    else:
        result = "逊啊！"
        passing=False

    if passing:
        buttons.append(button_nextlevel)

    hei = int(block_wid / 2)
    text_result=text0("  " + result,hei,texts[0].x+texts[0].wid,texts[0].y,color=light(RED))
    texts_new=texts+[text_result]

    while run:
        screen.fill(light(GREEN))
        for r in range(9):
            for c in range(16):
                blocks[r][c].draw()

        for butt in buttons:
            butt.draw()

        for text in texts_new:
            text.draw()



        clock.tick(fps)
        pygame.display.update()
        for event in pygame.event.get():
            if event.type==QUIT:
                run=False
                return None,None
            elif event.type==MOUSEBUTTONDOWN:
                if button_restart.focused():
                    return "run_level",level
                if passing:
                    if button_nextlevel.focused():
                        try:
                            if "Level" in level:
                                nextlevel=levels[levels.index(level)+1]
                            else:
                                nextlevel=designs[designs.index(level)+1]
                        except:
                            return "menu",None
                    elif button_menu.focused():
                        return "menu",None


def run_level(level):
    global run
    #读文件
    file=open("Levels/"+level+".txt")
    file_lines=file.readlines()
    file.close()

    #建立二维列表blocks
    blocks=file_lines[0:9]
    for i in range(9):
        blocks[i]=list(blocks[i])

    #读取步数
    if len(file_lines)==9:
        max_steps="不限"
    else:
        max_steps=file_lines[9]
    step=0

    #读取可动方块，生成字典{'代号':(行,列)}
    rc_dict={}
    for r in range(9):
        for c in range(16):
            if blocks[r][c]=='A':
                rc_dict['A']=(r,c)
            elif blocks[r][c]=='B':
                rc_dict['B']=(r,c)
            blocks[r][c]=(block(blocks[r][c],r,c))

    #按钮
    buttons=[button_menu,button_restart]


    #文案
    hei = int(block_wid / 2)
    text_step = text0("步数：" + str(step) + "/" + str(max_steps), hei, X0, Y0 - hei - unit_pixel)
    text_title = text0(level, hei, X0, Y0 - 2 * (hei + unit_pixel))

    texts = [text_step,text_title]


    #主程序
    moved,passing=False,False
    while run:
        screen.fill(light(GREEN))



        for text in texts:
            text.draw()

        #textImage=myfont.render("步数："+str(step)+"/"+str(max_steps),True,BLACK)
        #screen.blit(textImage,(screen_wid/2-block_wid*8,screen_hei/2-4.5*block_wid-textImage.get_height()))

        for r in range(9):
            for c in range(16):
                if blocks[r][c].type!='_':
                    blocks[r][c].draw()

        for butt in buttons:
            butt.draw()

        clock.tick(fps)
        pygame.display.update()

        for event in pygame.event.get():
            if event.type==QUIT:
                run=False
                return None,None
            elif event.type==KEYDOWN:
                if event.key==K_d:
                    moved,passing=move(blocks,buttons,texts,rc_dict,'right')
                elif event.key==K_w:
                    moved,passing=move(blocks,buttons,texts,rc_dict,'up')
                elif event.key==K_a:
                    moved,passing=move(blocks,buttons,texts,rc_dict,'left')
                elif event.key==K_s:
                    moved,passing=move(blocks,buttons,texts,rc_dict,'down')
            elif event.type==MOUSEBUTTONDOWN:
                if button_restart.focused():
                    return "run_level",level
                elif button_menu.focused():
                    return "menu",None

        if moved:
            step+=1
            texts[0].content = "步数：" + str(step) + "/" + str(max_steps)
            texts[0].refresh()
            moved=False
        if passing:
            return show_result(blocks,texts,step,max_steps,level)

def menu():
    global run
    text_title=text0("推箱子",block_wid,0,screen_hei/2-4.5*block_wid-block_wid-unit_pixel)
    text_title.x=screen_wid/2-text_title.wid/2
    text_title.refresh()
    text_level=text0("闯关",hei,X0,Y0+4*unit_pixel)
    text_design=text0("自创",hei,X0,screen_hei/2)
    texts=[text_title,text_level,text_design]

    path="Levels/"


    buttons_level=[]
    x_level=X0
    y_level=Y0+block_wid
    for level in levels:
        button_level=button(level,x_level,y_level)
        if button_level.x+button_level.wid>=screen_wid/2+8*block_wid:
            button_level.x=X0
            button_level.y+=block_wid
            y_level=button_level.y
        buttons_level.append(button_level)
        x_level = button_level.x + button_level.wid + unit_pixel


    buttons_design=[]
    x_design=X0
    y_design=screen_hei/2+block_wid
    for design in designs:
        button_design=button(design,x_design,y_design)
        if button_design.x+button_design.wid>=screen_wid/2+8*block_wid:
            button_design.x=X0
            button_design.y+=block_wid
            y_design=button_design.y
        buttons_design.append(button_design)
        x_design = button_design.x + button_design.wid + unit_pixel

    buttons=buttons_design+buttons_level

    while run:
        screen.fill(light(GREEN))
        for text in texts:
            text.draw()
        for butt in buttons:
            butt.draw()
        clock.tick(fps)
        pygame.display.update()
        for event in pygame.event.get():
            if event.type==QUIT:
                run=False
                return None,None
            elif event.type==MOUSEBUTTONDOWN:
                for but in buttons_level:
                    if but.focused():
                        return "run_level","Level"+but.text
                for but in buttons_design:
                    if but.focused():
                        return "run_level","Design"+but.text







def run_page(page,level=None):
    if page=="menu":
        return menu()
    elif page=="run_level":
        return run_level(level)

def main():
    global run
    page="menu"
    level=None
    while run:
        page,level=run_page(page,level)
    pygame.quit()

main()


